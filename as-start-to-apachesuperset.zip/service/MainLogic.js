const Log           = require("../components/log.js");
const dbFile        = require("../components/db_File.js");
const config        = require("config");
const path          = require('path');
const api_Start     = require("../http/api_Start.js");
const api_Superset  = require("../http/api_Superset.js")

/** Флаг указывающий что в данный момент идет синхронизация */
let syncOn = false;
/** Отключение/включение проверки SSL сертификата "Старта" */
process.env.NODE_TLS_REJECT_UNAUTHORIZED = config.get("api_check_ssl") == true? 1 : 0;

class MainLogic extends Log {     
    name = "MainLogic";  
   
    async createChart() {
      try {
        /** логинимся */
        const {access_token, refresh_token} = await api_Superset.getAuthTokens()
        console.log(token)
        /** Получаем проекты из "Старта" */
        const _createChart = await api_Superset.createChart(access_token);
      } catch (error) {
        console.log(error)
      }
    }

     /** Функция для переодического вызова функции синхронизации всех проектов */
    async autoSync(){
        let polling_time = config.get("api_check_sync_period") * 1000;;
        /** Если синхронизация не выполняется в данный момент то запускаем */
        if (!syncOn) {
            syncOn = true;  
          //  const result = await this.updateProjects();
            const result = await api_Superset.getAuthTokens()
            console.log(result);
            syncOn = false;
        }        
        /** Устанавливаем время следующего вызова */
        setTimeout(()=>{
            this.autoSync();
        }, polling_time );
        this.blue(`sync_interval: ${config.get("api_sync_period")} seconds`);
    }
}

module.exports = new MainLogic();