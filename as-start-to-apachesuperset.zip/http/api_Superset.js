const Log       = require("../components/log.js");
const axios     = require('axios');
const config    = require("config");
const host      = config.get('api_superset_host')

class api_Superset extends Log {     
    name = "api_Superset";

     
    async createChart(access_token){

    }
    /** Авторизация */
    async getAuthTokens(){
        try {
            const password  = config.get('api_superset_auth.password')
            const login     = config.get('api_superset_auth.login')
            const endpoint  = config.get('api_superset_url.login')
            const url       = host + endpoint
        // Заголовки
            const req_config = {
            headers: {
            'Content-Type': 'application/json; charset=UTF-8'
            }};
        // Тело запроса
            const data =  {
                password: password,
                provider: "db",
                refresh: true,
                username: login
              }
        // Получаем токен
            let access_token = null;
            let refresh_token = null;
            
            await axios.post(url, data, req_config)
            .then(response => {
               // if (response.data.jwt) token = response.data.jwt    
               //console.log(response.data)     
               access_token  = response.data.access_token   
               refresh_token = response.data.refresh_token  
            }).catch(error => {
                console.log("Ошибка авторизации в Superset")
               // console.log(error)
            });

            return {access_token, refresh_token}
        } catch (error) {
            console.log(error)
        }
    }
}

module.exports =  new api_Superset();